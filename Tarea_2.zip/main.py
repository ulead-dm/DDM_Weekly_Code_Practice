from cesar import metodo_cesar
from vignere import metodo_vigenere

print('Bienvenido al encriptador/desencriptador')
print(40*'-')
print('Seleccione el método que desea usar:')
print()
print('1. Cifrado César')
print('2. Cifrado Vigenère')
print("(Ingrese 'q' para salir)")
print(40*'-')

while True:
    metodo = input('Ingrese 1, 2 o q: ').strip().lower()
    print(40*'-')
    if metodo == '1':
        metodo_cesar()
    elif metodo == '2':
        metodo_vigenere()
    elif metodo == 'q':
        print('Saliendo...')
        break
    else:
        print("Opción no válida. Intente de nuevo.")

