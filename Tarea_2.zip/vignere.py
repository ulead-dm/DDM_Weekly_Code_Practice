def encriptar_vigenere(texto, clave):
    resultado = ""
    clave_repetida = ""
    clave_length = len(clave)
    j = 0

    for i in range(len(texto)):
        if texto[i].isalpha():
            clave_repetida += clave[j % clave_length]
            j += 1
        else:
            clave_repetida += texto[i]

    for i in range(len(texto)):
        if texto[i].isalpha():
            desplazamiento_base = ord('A') if texto[i].isupper() else ord('a')
            desplazamiento_clave = ord(clave_repetida[i].upper()) - ord('A')
            nuevo_char = chr((ord(texto[i]) - desplazamiento_base + desplazamiento_clave) % 26 + desplazamiento_base)
            resultado += nuevo_char
        else:
            resultado += texto[i]

    return resultado

def desencriptar_vigenere (texto, clave):
    resultado = ""
    clave_repetida = ""
    clave_length = len(clave)
    j = 0

    for i in range(len(texto)):
        if texto[i].isalpha():
            clave_repetida += clave[j % clave_length]
            j += 1
        else:
            clave_repetida += texto[i]

    for i in range(len(texto)):
        if texto[i].isalpha():
            desplazamiento_base = ord('A') if texto[i].isupper() else ord('a')
            desplazamiento_clave = ord(clave_repetida[i].upper()) - ord('A')
            nuevo_char = chr((ord(texto[i]) - desplazamiento_base - desplazamiento_clave) % 26 + desplazamiento_base)
            resultado += nuevo_char
        else:
            resultado += texto[i]

    return resultado



def metodo_vigenere():
    texto = input('Ingrese el texto a encriptar/desencriptar: ')
    clave = input('Ingrese la palabra clave: ')
    print(40*'-')
    accion = input('¿Desea encriptar o desencriptar? (e/d): ').lower()
    print(40*'-')
    if accion == 'e':
        resultado = encriptar_vigenere(texto, clave)
        print()
        print(f'Texto encriptado: {resultado}')
        print(40*'-')
    elif accion == 'd':
        resultado = desencriptar_vigenere(texto, clave)
        print()
        print(f'Texto desencriptado: {resultado}')
        print(40*'-')
    else:
        print()
        print('Acción no válida. Por favor ingrese "e" para encriptar o "d" para desencriptar.')
        print(40*'-')