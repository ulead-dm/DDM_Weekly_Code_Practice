def encriptar_cesar(texto, desplazamiento):
    resultado = ""

    for char in texto:
        if char.isalpha():
            desplazamiento_base = ord('A') if char.isupper() else ord('a')
            nuevo_char = chr((ord(char) - desplazamiento_base + desplazamiento) % 26 + desplazamiento_base)
            resultado += nuevo_char
        else:
            resultado += char

    return resultado

def desencriptar_cesar(texto, desplazamiento):
    return encriptar_cesar(texto, -desplazamiento)

def metodo_cesar():
    texto = input('Ingrese el texto a encriptar/desencriptar: ')
    while True:
        try:
            desplazamiento = int(input('Ingrese el desplazamiento (número entero): '))
            print(40*'-')
            break
        except ValueError:
            print('Desplazamiento inválido. Ingrese un número entero.')
            print(40*'-')
    accion = input('¿Desea encriptar o desencriptar? (e/d): ').lower()
    print(40*'-')
    if accion == 'e':
        resultado = encriptar_cesar(texto, desplazamiento)
        print()
        print(f'Texto encriptado: {resultado}')
        print(40*'-')
    elif accion == 'd':
        resultado = desencriptar_cesar(texto, desplazamiento)
        print()
        print(f'Texto desencriptado: {resultado}')
        print(40*'-')
    else:
        print()
        print('Acción no válida. Por favor ingrese "e" para encriptar o "d" para desencriptar.')