"""-Funciones
1. Haga una funcion que reciba 4 parametros, numericos, y calcula la pendiente de
una recta
2. Haga una funcion que recibe una lista de numeros e imprime el promedio
3. Haga una funcion que recibe una lista de numeros e imprime el mas grande y el
mas pequeño
4. Haga una funcion que recibe una lista de palabras y para cada palabra imprime las
vocales que tiene'"""

print('--------------Practice----------------')
print('Funciones:')
print()
print('Exercise 1:')

def calcular_pendiente(x1, y1, x2, y2):
    if x2 - x1 == 0:
        return "La pendiente es indefinida (línea vertical)."
    pendiente = (y2 - y1) / (x2 - x1)
    return pendiente


print(calcular_pendiente(2,2,7,5))