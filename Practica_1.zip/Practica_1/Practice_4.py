print('Practica semana 11 de septiembre del 2025')
print()

'''Práctica de Programacion
-General
1. Escriba un programa que lea números del teclado, si el numero leído es par
entonces va acumulando la suma de todos los pares introducidos. Termina si lee
del teclado un -1 e imprime el total sumado
2. Escriba un programa que lee números del teclado. Guarda en una lista los pares
positivos y en otra los impares positivos. Termina si meten cualquier numero
negativo. Al terminar imprime cuantos numeros pares e impares positivos se
introdujeron
3. Haga un programa que lee un numero, y luego tantas palabras como ese numero.
Luego mete todas las palabras en un set, e imprime el set.
4. Haga un programa que lee un numero, y luego tantas palabras como ese numero.
Luego mete todas las palabras en una tupla y pregunta por un numero e imprime la
palabra en esa posicion de la tupla.
5. Haga un programa que lea 5 numeros, los mete en una lista y luego escoge el mas
grande y el mas pequeño y los imprime.
6. Haga un programa que pida un numero y lea tantas palabras como la cantidad del
numero. Al final el programa imprime la mas larga.

-Funciones
1. Haga una funcion que reciba 4 parametros, numericos, y calcula la pendiente de
una recta
2. Haga una funcion que recibe una lista de numeros e imprime el promedio
3. Haga una funcion que recibe una lista de numeros e imprime el mas grande y el
mas pequeño
4. Haga una funcion que recibe una lista de palabras y para cada palabra imprime las
vocales que tiene'''

print('--------------Practice----------------')
print('General:')
print()
print('Exercise 4:')
palabras_introducidas = []


while True:
    try:
        numero = int(input("Ingrese un numero de palabras: "))
    except ValueError:
        print("Por favor, ingrese un valor válido.")
        continue
    if numero <= 0:
        print("El numero debe ser mayor a 0.")
        continue
    palabras_introducidas = []
    for i in range(numero):
        palabra = input(f"Ingrese la palabra {i + 1}: ")
        palabras_introducidas.append(palabra)
    palabras_tupla = tuple(palabras_introducidas)
    while True:
        try:
            seleccion = int(input(f"Ingrese un numero entre 1 y {len(palabras_tupla)} para ver la palabra en esa posicion: "))
        except ValueError:
            print("Por favor, ingrese un valor válido.")
            continue
        if seleccion < 1 or seleccion > len(palabras_tupla):
            print("Numero fuera de rango, intente de nuevo.")
            continue
        print(f"La palabra en la posicion {seleccion} es: {palabras_tupla[seleccion - 1]}")
        break
    break

 


    
