"""-Funciones
1. Haga una funcion que reciba 4 parametros, numericos, y calcula la pendiente de
una recta
2. Haga una funcion que recibe una lista de numeros e imprime el promedio
3. Haga una funcion que recibe una lista de numeros e imprime el mas grande y el
mas pequeño
4. Haga una funcion que recibe una lista de palabras y para cada palabra imprime las
vocales que tiene'"""

print('--------------Practice----------------')
print('Funciones:')
print()
print('Exercise 3:')

def max_min(numeros):
    if not numeros:
        return None, None
    
    numero_mas_grande = max(numeros)
    numero_mas_pequeno = min(numeros)
    return (f"El numero mas grande es:", numero_mas_grande), (f"El numero mas pequeño es:", numero_mas_pequeno)

print(max_min([10,20,1,40,80]))