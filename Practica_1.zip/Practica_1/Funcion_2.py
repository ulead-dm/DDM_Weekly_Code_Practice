"""-Funciones
1. Haga una funcion que reciba 4 parametros, numericos, y calcula la pendiente de
una recta
2. Haga una funcion que recibe una lista de numeros e imprime el promedio
3. Haga una funcion que recibe una lista de numeros e imprime el mas grande y el
mas pequeño
4. Haga una funcion que recibe una lista de palabras y para cada palabra imprime las
vocales que tiene'"""

print('--------------Practice----------------')
print('Funciones:')
print()
print('Exercise 2:')

def calcular_promedio(numeros):
    if not numeros:
        return 0
    
    return sum(numeros) / len(numeros)

print(calcular_promedio([10,20,30,40,50]))