print('Practica semana 11 de septiembre del 2025')
print()

'''Práctica de Programacion
-General
1. Escriba un programa que lea números del teclado, si el numero leído es par
entonces va acumulando la suma de todos los pares introducidos. Termina si lee
del teclado un -1 e imprime el total sumado
2. Escriba un programa que lee números del teclado. Guarda en una lista los pares
positivos y en otra los impares positivos. Termina si meten cualquier numero
negativo. Al terminar imprime cuantos numeros pares e impares positivos se
introdujeron
3. Haga un programa que lee un numero, y luego tantas palabras como ese numero.
Luego mete todas las palabras en un set, e imprime el set.
4. Haga un programa que lee un numero, y luego tantas palabras como ese numero.
Luego mete todas las palabras en una tupla y pregunta por un numero e imprime la
palabra en esa posicion de la tupla.
5. Haga un programa que lea 5 numeros, los mete en una lista y luego escoge el mas
grande y el mas pequeño y los imprime.
6. Haga un programa que pida un numero y lea tantas palabras como la cantidad del
numero. Al final el programa imprime la mas larga.

-Funciones
1. Haga una funcion que reciba 4 parametros, numericos, y calcula la pendiente de
una recta
2. Haga una funcion que recibe una lista de numeros e imprime el promedio
3. Haga una funcion que recibe una lista de numeros e imprime el mas grande y el
mas pequeño
4. Haga una funcion que recibe una lista de palabras y para cada palabra imprime las
vocales que tiene'''

print('--------------Practice----------------')
print('General:')
print()
print('Exercise 1:')

par_introducido = 0
while True:
    try:
        numero = int(input("Ingrese un numero (o -1 para terminar): "))
    except ValueError:
        print("Por favor, ingrese un número válido.")
        continue
    if numero == -1:
        print('La suma total de numeros pares es:', par_introducido)
        break
    elif numero % 2 == 0:
        par_introducido += numero