print('Practica semana 11 de septiembre del 2025')
print()

'''Práctica de Programacion
-General
1. Escriba un programa que lea números del teclado, si el numero leído es par
entonces va acumulando la suma de todos los pares introducidos. Termina si lee
del teclado un -1 e imprime el total sumado
2. Escriba un programa que lee números del teclado. Guarda en una lista los pares
positivos y en otra los impares positivos. Termina si meten cualquier numero
negativo. Al terminar imprime cuantos numeros pares e impares positivos se
introdujeron
3. Haga un programa que lee un numero, y luego tantas palabras como ese numero.
Luego mete todas las palabras en un set, e imprime el set.
4. Haga un programa que lee un numero, y luego tantas palabras como ese numero.
Luego mete todas las palabras en una tupla y pregunta por un numero e imprime la
palabra en esa posicion de la tupla.
5. Haga un programa que lea 5 numeros, los mete en una lista y luego escoge el mas
grande y el mas pequeño y los imprime.
6. Haga un programa que pida un numero y lea tantas palabras como la cantidad del
numero. Al final el programa imprime la mas larga.

-Funciones
1. Haga una funcion que reciba 4 parametros, numericos, y calcula la pendiente de
una recta
2. Haga una funcion que recibe una lista de numeros e imprime el promedio
3. Haga una funcion que recibe una lista de numeros e imprime el mas grande y el
mas pequeño
4. Haga una funcion que recibe una lista de palabras y para cada palabra imprime las
vocales que tiene'''

print('--------------Practice----------------')
print('General:')
print()
print('Exercise 6:')

while True:
    try:
        numero = int(input("Ingrese un numero: "))
    except ValueError:
        print('Ingrese un numero valido')
        continue
    if numero <= 0:
        print('Ingrese un numero valido')
        continue
    palabras_lista = []
    for i in range(numero):
        palabra = input(f"Ingrese la palabra {i + 1}: ")
        palabras_lista.append(palabra)
    palabra_mas_larga = max(palabras_lista, key=len)
    print(f'La palabra más larga es: {palabra_mas_larga}')
    break
        

 


    
