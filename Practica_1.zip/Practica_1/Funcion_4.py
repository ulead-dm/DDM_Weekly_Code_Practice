"""-Funciones
1. Haga una funcion que reciba 4 parametros, numericos, y calcula la pendiente de
una recta
2. Haga una funcion que recibe una lista de numeros e imprime el promedio
3. Haga una funcion que recibe una lista de numeros e imprime el mas grande y el
mas pequeño
4. Haga una funcion que recibe una lista de palabras y para cada palabra imprime las
vocales que tiene'"""

print('--------------Practice----------------')
print('Funciones:')
print()
print('Exercise 3:')

def vocales_por_palabra(palabras):
    vocales = 'aeiouAEIOU'
    resultado = {}
    
    for palabra in palabras:
        vocales_en_palabra = set([letra for letra in palabra if letra in vocales])
        resultado[palabra] = vocales_en_palabra
    
    return resultado

print(vocales_por_palabra(["hola", "mundo", "python", "programacion"]))