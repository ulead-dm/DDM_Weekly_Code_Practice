from Codigo_Modulos.Transformacion_de_codigo import csv_to_format

def main():
    print()
    print(40 * '-')
    print("Programa transformador de formatos")
    print(40 * '-')
    print("Ingrese la ruta del archivo CSV: ")
    print("Ruta elegida ( currency.csv ) ")
    print(40 * '-')
    print('Formatos disponibles:')
    print()
    print('- XML. ')
    print('- JSON. ')
    print('- Tramas de bytes. (dat)')
    print(40 * '-')
    formato_elegido = input("Ingrese el formato de salida (xml/json/dat): ").strip().lower()
    print(40 * '-')
    print()
    path= 'currency.csv'
    csv_to_format(path, formato_elegido)
