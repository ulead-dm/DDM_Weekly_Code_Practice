import os
import csv
import xml.etree.ElementTree as ET
import json



def csv_to_format(csv_file_path, output_format='xml'):
    # Leer archivo CSV
    with open(csv_file_path, mode='r', encoding='utf-8') as csv_file:
        reader = csv.DictReader(csv_file)
        columns = reader.fieldnames

        print(f"Columnas disponibles: {columns}")
        print()
        choice = input("¿Quieres usar todas las columnas o seleccionar algunas? (todas/algunas): ").strip().lower()
        print(40 * '-')
        if choice == 'todas':
            selected_columns = columns
        elif choice == 'algunas':
            print()
            print("Columnas disponibles para seleccionar:")
            for idx, col in enumerate(columns, 1):
                print(f"{idx}- {col}")
            print(40 * '-')
            selected_columns_input = input("Escriba el número de columnas que desea usar separadas por coma (ejemplo: 2,3,4): ")
            try:
                indices = [int(num.strip()) for num in selected_columns_input.split(',')]
                selected_columns = [columns[i-1] for i in indices if 1 <= i <= len(columns)]
            except Exception:
                print("Entrada inválida, se usarán todas las columnas.")
                selected_columns = columns
        else:
            print("Elección no válida, se usarán todas las columnas.")
            selected_columns = columns

        # Preparar datos seleccionados
        csv_file.seek(0)  # Volver al inicio para leer datos completos
        reader = csv.DictReader(csv_file)

        base_name = os.path.splitext(csv_file_path)[0]
        if output_format == 'xml':
            root = ET.Element('root')
            for row in reader:
                item = ET.Element('item')
                for col in selected_columns:
                    child = ET.SubElement(item, col)
                    child.text = row[col]
                root.append(item)
            tree = ET.ElementTree(root)
            output_file_path = f"{base_name}.xml"
            tree.write(output_file_path, encoding='utf-8', xml_declaration=True)

        elif output_format == 'json':
            data = []
            for row in reader:
                data.append({col: row[col] for col in selected_columns})
            output_file_path = f"{base_name}.json"
            with open(output_file_path, 'w', encoding='utf-8') as json_file:
                json.dump(data, json_file, ensure_ascii=False, indent=4)

        elif output_format == 'dat':
            output_file_path = f"{base_name}.dat"
            with open(output_file_path, 'w', encoding='utf-8') as dat_file:
                for row in reader:
                    line = ''.join(row[col] for col in selected_columns) + '\n'
                    dat_file.write(line)

        else:
            raise ValueError("Formato de salida no soportado")

        print(f"Archivo creado: {output_file_path}")


