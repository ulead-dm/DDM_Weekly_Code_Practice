'''Haga un programa que lea una lista de números enteros.
Dicha lista será considerada como una función de choque de asteroides.
El signo del numero indica la dirección: Si es positivo, va de derecha a izquierda, si es negativo
va de izquierda a derecha.
Cada vez que hay un positivo seguido de un negativo, o viceversa, hay un choque de asteroides.
El “resultado” será la consecuencia de la suma de ambos. Y la lista resultante deberá decir: 0
si el asteroide no choco, o el resultado del choque EN EL MAYOR si lo hubo.
Ejemplo:
[1,2,3,-5] resultaría en [0,0,0,-2]
[1,2,-5,7] resultaría en [0,0,0,2] Esto es un error, debería ser [0,0,-3,2]
[1,2,9,-5] resultaría en [0,0,4,0]
[1,2,-15,1] resultaría en [0,0,-14,0]
[1,2,9,-5,-10] resultaría en [0,0,4,0,0]
[1,2,-3,-15,1] resultaría en [0,0,-1,-14,0]'''

def process_pair(first, second):
    if (first > 0 and second < 0) or (first < 0 and second > 0):  # Choque
        suma = first + second
        if abs(first) >= abs(second):
            return [suma, 0]   # resultado queda en "first"
        else:
            return [0, suma]   # resultado queda en "second"
    else:
        return [first, second]  # si no chocan, se mantienen


def process_asteroids(asteroids):
    result = asteroids[:]  # copia original
    for i in range(len(result) - 1):
        if (result[i] > 0 and result[i+1] < 0) or (result[i] < 0 and result[i+1] > 0):
            new_first, new_second = process_pair(result[i], result[i+1])
            result[i], result[i+1] = new_first, new_second
    return [0 if (asteroids[i] == result[i]) else result[i] for i in range(len(asteroids))]


# Ejemplos de prueba:
print(process_asteroids([1,2,3,-5]))        # [0,0,0,-2]
print(process_asteroids([1,2,-5,7]))        # [0,0,-3,2]
print(process_asteroids([1,2,9,-5]))        # [0,0,4,0]
print(process_asteroids([1,2,-15,1]))       # [0,0,-14,0]
print(process_asteroids([1,2,9,-5,-10]))    # [0,0,4,0,0]
print(process_asteroids([1,2,-3,-15,1]))    # [0,0,-1,-14,0]

